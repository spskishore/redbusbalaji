package BASE_CLASSES;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import excel_utility.excel;

public class utilities extends excel{
	
	 	
	
	
		protected static WebDriver dr;
		
		
//		public WebElement waitForElement(By locator, int timeout) {
//			try {
//				WebDriverWait wait = new WebDriverWait(dr, timeout);
//				WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
//				System.out.println("Element Located");
//				return element;
//				
//			}catch(Exception e) {
//				System.out.println("Element not located " + e);
//			}
//			return null;
//		}
//		
//		public WebElement elementToBeClickable(By locator, int timeout) {
//			try {
//				WebDriverWait wait = new WebDriverWait(dr, timeout);
//				WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
//				System.out.println("Element Located");
//				return element;
//				
//			}catch(Exception e) {
//				System.out.println("Element not located " + e);
//			}
//			return null;
//		}
//		
//		static int counter=1;
//		public void getSS()
//		{
//			String path="C:\\Users\\BLTuser.BLT0191\\software\\";
//			String filename=counter + ".png";
//			
//			File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
//			File f2=new File(path+filename);
//			
//			try {
//				FileUtils.copyFile(f1, f2);
//
//			}catch (IOException e) {
//				System.out.println("Screen shot no. :" + counter + "failed");
//				e.printStackTrace();
//			}counter++;
//			
//		}
		
		public static WebDriver launch_browser(String browser, String url)
		{
			
			if(browser.contains("CHROME"))
			{
//			case "CHROME":
				System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Drivers\\chromedriver_v79.exe");
				dr= new ChromeDriver();
//				break;
			}	
//			case "FIREFOX":
			else if(browser.contains("FIREFOX")) {
				System.setProperty("webdriver.gecko.driver","src\\test\\resources\\Drivers\\geckoDriver.exe");
				dr = new FirefoxDriver();
//				break;
			}
			dr.get(url);
//			dr.manage().window().maximize();
			dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			return dr;
		}
//		public void date_picker(String date) {
//		
//		String exp_data=v.get_testdata();
//		System.out.println(exp_data);
//		int l=exp_data.length();
//		String d=exp_data.substring(1, l=l-1);
//		System.out.println(d);
//		
//		
//        String[] arrOfStr = d.split("-", 3); 
//  
//        for (String a : arrOfStr) 
//            System.out.println(a); 
//        
//          String exp_date=arrOfStr[0];
//          String exp_month=arrOfStr[1];
//          String exp_year=arrOfStr[2];
//          String p=exp_month+" ";
//          String q=p+exp_year;
//          
//          dr.findElement(By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']")).click();
//      	String act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();
//      	
//      	while(!act_year.equals(q))      	{
//      		dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[3]")).click();
//      		act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();
//
//
//      	}
//      	
//      	List <WebElement> rb=dr.findElements(By.xpath("//table[@class='rb-monthTable first last']//child::td"));
//      	
//      	for(WebElement el:rb)
//      	{
//      		String date=el.getText();
//      		if(exp_date.equals(date))
//      		{
//      			el.click();
//      		}
//
//
//	}
//	
//		
//}
		
	}


