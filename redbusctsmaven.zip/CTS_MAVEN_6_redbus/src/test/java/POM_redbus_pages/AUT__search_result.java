package POM_redbus_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT__search_result {
	

	By secondname= By.xpath("//div[@class='result-sec']/ul/div[2]/li/div/div/div/div[1]/div[1]");
	By secondprice= By.xpath("//div[@class='result-sec']/ul/div[2]/li/div/div/div/div[6]/div[1]/div[2]/span");

	
	
WebDriver dr;
		public  AUT__search_result(WebDriver dr)
		{this.dr=dr;}
		
		
		
		public String get_secondname()//getting name of second result
		{
			 return dr.findElement(secondname).getText();
			
		}
		
		public void get_secondprice()//getting price of second result
		{
			System.out.println(dr.findElement(secondprice).getText());
		}
		
		
		
		


}
