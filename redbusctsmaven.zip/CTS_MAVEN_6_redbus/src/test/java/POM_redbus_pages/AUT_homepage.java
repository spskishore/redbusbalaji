package POM_redbus_pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSES.utilities;

public class AUT_homepage  {
	
	
	WebDriver dr;
	By from=By.xpath("//div[@class='clearfix search-wrap']/div[1]/div/input");
	By fromsel=By.xpath("//div[@class='clearfix search-wrap']/div[1]/div/ul/li[1]");

	By to=By.xpath("//div[@class='clearfix search-wrap']/div[2]/div/input");
	By tosel=By.xpath("//div[@class='clearfix search-wrap']/div[2]/div/ul/li[1]");

	By on_date=By.xpath("//div[@class='clearfix search-wrap']/div[3]/div/input");
	By search=By.xpath("//div[@class='clearfix search-wrap']/button");
	
		
	public AUT_homepage(WebDriver dr)
	{
		System.out.println("in AUT_homepage");
		this.dr=dr;
	}
	
	public void set_from(String fr)
	{
		System.out.println("in set_from");
		dr.findElement(from).sendKeys(fr);
		dr.findElement(fromsel).click();

	}
	
	public void set_to(String too)
	{
		System.out.println("in set_set");
		dr.findElement(to).sendKeys(too);
		dr.findElement(tosel).click();

	}
	
	public void set_ondate(String od)
	{
		System.out.println("in set_ondate");
			
			String exp_data=od;
			System.out.println(exp_data);
			int l=exp_data.length();
			String d=exp_data.substring(1, l=l-1);
			System.out.println(d);
			
			
	        String[] arrOfStr = d.split("-", 3); 
	  
	        for (String a : arrOfStr) 
	            System.out.println(a); 
	        
	          String exp_date=arrOfStr[0];
	          String exp_month=arrOfStr[1];
	          String exp_year=arrOfStr[2];
	          String p=exp_month+" ";
	          String q=p+exp_year;
	          
	          dr.findElement(By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']")).click();
	      	String act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();
	      	
	      	while(!act_year.equals(q))      	{
	      		dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[3]")).click();
	      		act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();


	      	}
	      	
	      	List <WebElement> rb=dr.findElements(By.xpath("//table[@class='rb-monthTable first last']//child::td"));
	      	
	      	for(WebElement el:rb)
	      	{
	      		String date=el.getText();
	      		if(exp_date.equals(date))
	      		{
	      			el.click();
	      		}


		}
		
			
	

		dr.findElement(on_date).sendKeys(od);
	}
	
	public void set_search()
	{
		System.out.println("in set_search");
		dr.findElement(search).click();}
	
	public void do_search(String f, String t, String o)// performing do_search
	{
		try {
			Thread.sleep(5000);
			
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		this.set_from(f);
		this.set_to(t);
		this.set_ondate(o);
		this.set_search();
	}
	
	

}
