package POM_testng_redbus;

import java.io.FileNotFoundException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.utilities;
import POM_redbus_pages.AUT_homepage;
import POM_redbus_pages.AUT__search_result;

public class test_AUT_login_1 extends utilities{
	
	AUT__search_result search_result;
	AUT_homepage homepage;

	
	@BeforeMethod
	public void get_data() throws FileNotFoundException
	{
		System.out.println("in bm");

		dr=utilities.launch_browser("CHROME", "https://www.redbus.in/");//launching chrome browser
	}
	  @Test(dataProvider="search_data")
	  public void t1(String from, String to, String ondate) {
			System.out.println("in test");

			homepage=new AUT_homepage(dr);
		  
			homepage.do_search(from, to, ondate); //performing search in from, to & on date
			search_result=new AUT__search_result(dr);
		  String secondname=search_result.get_secondname();
		  System.out.println(secondname);
		  search_result.get_secondprice();
		  SoftAssert sa= new SoftAssert();
		  sa.assertEquals(secondname, "National travels"); //actul and exp ressult passed
		  sa.assertAll();
	  }
	  @DataProvider(name="search_data")
	  public String[][] provide_data() throws FileNotFoundException
	  {
			System.out.println("in dataprovider");

		  
			get_testdata(); //reding from excel

		 return testdata1;
	  }
}


